package com.prazdnik.vpn

import android.content.Context
import android.content.Intent
import android.util.Log
import io.github.tim06.openvpn.OpenVPNConfig
import io.github.tim06.openvpn.OpenVPNService

/**
 * Мост к OpenVPN-движку (библиотека io.github.tim06:openvpn, Apache 2.0).
 * Создаёт настоящий системный VPN-туннель через Android VpnService.
 */
object VpnManager {

    fun start(context: Context, ovpnConfig: String) {
        OpenVPNService.startService(
            context,
            OpenVPNConfig(configuration = ovpnConfig)
        )
    }

    fun stop(context: Context) {
        // 1) Универсальный способ: остановить сервис движка как обычный Android Service
        try {
            context.stopService(Intent(context, OpenVPNService::class.java))
        } catch (e: Exception) {
            Log.w(TAG, "stopService(intent) не сработал", e)
        }
        // 2) Запасной вариант: companion-метод stopService, если он есть в этой версии библиотеки
        stopViaReflection(context)
    }

    private fun stopViaReflection(context: Context) {
        val classes = mutableListOf(OpenVPNService::class.java)
        try {
            classes.add(Class.forName("io.github.tim06.openvpn.OpenVPNService\$Companion"))
        } catch (e: Exception) {
            // companion отсутствует - не страшно
        }
        for (clazz in classes) {
            try {
                val method = clazz.getMethod("stopService", Context::class.java)
                val target = if (clazz.simpleName == "Companion") {
                    try {
                        OpenVPNService::class.java.getDeclaredField("Companion").get(null)
                    } catch (e: Exception) {
                        null
                    }
                } else null
                method.invoke(target, context)
                return
            } catch (e: NoSuchMethodException) {
                // пробуем следующий класс
            }
        }
        Log.w(TAG, "stopService() в библиотеке не найден; остановка через уведомление VPN")
    }

    private const val TAG = "VpnManager"
}
