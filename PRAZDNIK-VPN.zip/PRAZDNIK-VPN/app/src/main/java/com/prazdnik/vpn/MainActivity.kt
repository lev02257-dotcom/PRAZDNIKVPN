package com.prazdnik.vpn

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.prazdnik.vpn.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    data class VpnLocation(val name: String, val flag: String, val assetName: String)

    private lateinit var binding: ActivityMainBinding
    private var vpnActive = false

    private val locations = listOf(
        VpnLocation("Нидерланды", "🇳🇱", "nl.ovpn"),
        VpnLocation("Германия", "🇩🇪", "de.ovpn"),
        VpnLocation("Великобритания", "🇬🇧", "gb.ovpn"),
        VpnLocation("Франция", "🇫🇷", "fr.ovpn"),
        VpnLocation("США", "🇺🇸", "us.ovpn"),
    )

    private var selected: VpnLocation = locations[0]

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) startVpn()
            else toast(getString(R.string.vpn_permission_denied))
        }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            runOnUiThread { setVpnUi(true) }
        }
        override fun onLost(network: Network) {
            runOnUiThread { setVpnUi(false) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initChips()

        binding.connectButton.setOnClickListener { toggleVpn() }
        binding.supportButton.setOnClickListener { writeToSupport() }

        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.registerNetworkCallback(
            NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_VPN)
                .build(),
            networkCallback
        )
        setVpnUi(isVpnActive(cm))
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.unregisterNetworkCallback(networkCallback)
        } catch (e: Exception) {
            // callback уже снят
        }
    }

    private fun initChips() {
        locations.forEachIndexed { index, loc ->
            val chip = Chip(this).apply {
                text = "${loc.flag}  ${loc.name}"
                isCheckable = true
                isChecked = index == 0
            }
            chip.setOnCheckedChangeListener { _, checked ->
                if (checked) {
                    selected = loc
                    if (vpnActive) {
                        toast(getString(R.string.location_switched, loc.name))
                    }
                }
            }
            binding.locationsGroup.addView(chip)
        }
    }

    private fun toggleVpn() {
        if (vpnActive) {
            VpnManager.stop(this)
            return
        }
        val config = readAsset(selected.assetName)
        if (config == null || !config.contains("remote ")) {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.err_no_config_title)
                .setMessage(
                    getString(
                        R.string.err_no_config_msg,
                        "${selected.flag} ${selected.name}"
                    )
                )
                .setPositiveButton(R.string.ok, null)
                .show()
            return
        }
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else startVpn()
    }

    private fun startVpn() {
        val config = readAsset(selected.assetName) ?: return
        binding.statusText.text =
            getString(R.string.connecting_to, selected.flag, selected.name)
        try {
            VpnManager.start(this, config)
        } catch (e: Exception) {
            toast(getString(R.string.connect_error, e.message ?: "unknown"))
            setVpnUi(false)
        }
    }

    private fun setVpnUi(active: Boolean) {
        vpnActive = active
        if (active) {
            binding.statusText.text =
                getString(R.string.connected_to, selected.flag, selected.name)
            binding.connectButton.text = getString(R.string.disconnect)
            binding.connectButton.backgroundTintList =
                ColorStateList.valueOf(getColor(R.color.red))
        } else {
            binding.statusText.text = getString(R.string.status_disconnected)
            binding.connectButton.text = getString(R.string.connect)
            binding.connectButton.backgroundTintList =
                ColorStateList.valueOf(getColor(R.color.green))
        }
    }

    private fun isVpnActive(cm: ConnectivityManager): Boolean =
        cm.allNetworks.any {
            cm.getNetworkCapabilities(it)
                ?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        }

    private fun readAsset(name: String): String? =
        try {
            assets.open(name).bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        }

    private fun writeToSupport() {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:prazdnikvpnsupport@gmail.com")
            putExtra(Intent.EXTRA_SUBJECT, "PRAZDNIK VPN - поддержка")
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast(getString(R.string.no_mail_app))
        }
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
