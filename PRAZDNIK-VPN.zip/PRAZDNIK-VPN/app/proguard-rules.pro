# Пока обфускация отключена (minifyEnabled false).
